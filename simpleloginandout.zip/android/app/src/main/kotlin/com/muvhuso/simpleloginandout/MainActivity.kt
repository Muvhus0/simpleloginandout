package com.muvhuso.simpleloginandout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
